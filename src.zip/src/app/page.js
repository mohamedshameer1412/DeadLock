
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  GraduationCap,
  Lock,
  Mail,
  UserRound,
} from "lucide-react";

export default function LoginPage() {
  const [mode, setMode] = useState("login");
  const [direction, setDirection] = useState(1);

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  const [error, setError] = useState("");

  const isLogin = mode === "login";

  function updateField(field, value) {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  }

  function switchToRegister() {
    setError("");
    setDirection(1);
    setMode("register");
  }

  function switchToLogin() {
    setError("");
    setDirection(-1);
    setMode("login");
  }

  function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (!isLogin) {
      if (formData.password.length < 8) {
        setError("Password must contain at least 8 characters.");
        return;
      }

      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match.");
        return;
      }
    }

    // Frontend demonstration only.
    // Connect your NEXUS backend API here.
    alert(isLogin ? "Login form validated." : "Registration form validated.");
  }

  return (
    <main className="auth-page">

      {/* LEFT: NEXUS BRANDING */}

      <section className="brand-panel">
        <div className="brand-content">

          <div className="brand-logo">
            <div className="logo-mark">
              N
            </div>

            <span>NEXUS</span>
          </div>

          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={mode}
              className="brand-message"
              initial={{ opacity: 0, x: direction * 45 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: direction * -45 }}
              transition={{ duration: 0.4 }}
            >
              <div className="eyebrow">
                <GraduationCap size={17} />
                INTELLIGENT LEARNING
              </div>

              <h2>
                {isLogin
                  ? "Master Your Potential."
                  : "Your Journey Starts Here."}
              </h2>

              <p>
                {isLogin
                  ? "Unlock Your Future."
                  : "Learn with purpose. Grow with confidence."}
              </p>

              <div className="brand-features">
                <Feature text="Personalized learning experience" />
                <Feature text="Track your academic mastery" />
                <Feature text="Learn. Test. Improve." />
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="brand-footer">
            <span className="status-dot" />
            YOUR LEARNING. YOUR PROGRESS.
          </div>

        </div>

        <div className="circle circle-one" />
        <div className="circle circle-two" />
        <div className="grid-overlay" />
      </section>

      {/* RIGHT: FORM */}

      <section className="form-panel">
        <div className="form-container">

          <AnimatePresence
            mode="wait"
            initial={false}
          >
            {isLogin ? (
              <LoginForm
                key="login"
                direction={direction}
                formData={formData}
                updateField={updateField}
                showPassword={showPassword}
                setShowPassword={setShowPassword}
                error={error}
                onSubmit={handleSubmit}
                switchMode={switchToRegister}
              />
            ) : (
              <RegisterForm
                key="register"
                direction={direction}
                formData={formData}
                updateField={updateField}
                showPassword={showPassword}
                setShowPassword={setShowPassword}
                showConfirm={showConfirm}
                setShowConfirm={setShowConfirm}
                error={error}
                onSubmit={handleSubmit}
                switchMode={switchToLogin}
              />
            )}
          </AnimatePresence>

        </div>
      </section>

    </main>
  );
}

/* LOGIN FORM */

function LoginForm({
  direction,
  formData,
  updateField,
  showPassword,
  setShowPassword,
  error,
  onSubmit,
  switchMode,
}) {
  return (
    <motion.div
      className="form-wrapper"
      initial={{ opacity: 0, x: direction * 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: direction * -100 }}
      transition={{
        duration: 0.45,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      <AuthHeader
        title="Welcome back"
        subtitle="Continue your learning journey."
      />

      <form
        className="auth-form"
        onSubmit={onSubmit}
      >
        <InputField
          label="Email address"
          type="email"
          placeholder="you@example.com"
          icon={<Mail size={18} />}
          value={formData.email}
          onChange={(value) => updateField("email", value)}
        />

        <InputField
          label="Password"
          type={showPassword ? "text" : "password"}
          placeholder="Enter your password"
          icon={<Lock size={18} />}
          value={formData.password}
          onChange={(value) => updateField("password", value)}
          endIcon={
            <PasswordToggle
              visible={showPassword}
              onClick={() => setShowPassword(!showPassword)}
            />
          }
        />

        <div className="form-options">
          <label className="check-label">
            <input type="checkbox" />
            Remember me
          </label>

          <button
            type="button"
            className="text-link"
            onClick={() => alert("Forgot password flow coming soon.")}
          >
            Forgot password?
          </button>
        </div>

        <ErrorMessage error={error} />

        <SubmitButton text="Sign in" />
      </form>

      <SwitchAuth
        text="Don't have an account?"
        action="Create account"
        onClick={switchMode}
      />
    </motion.div>
  );
}

/* REGISTER FORM */

function RegisterForm({
  direction,
  formData,
  updateField,
  showPassword,
  setShowPassword,
  showConfirm,
  setShowConfirm,
  error,
  onSubmit,
  switchMode,
}) {
  return (
    <motion.div
      className="form-wrapper"
      initial={{ opacity: 0, x: direction * 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: direction * -100 }}
      transition={{
        duration: 0.45,
        ease: [0.22, 1, 0.36, 1],
      }}
    >
      <AuthHeader
        title="Create your account"
        subtitle="Start building your learning mastery."
      />

      <form
        className="auth-form"
        onSubmit={onSubmit}
      >
        <InputField
          label="Full name"
          type="text"
          placeholder="Your full name"
          icon={<UserRound size={18} />}
          value={formData.name}
          onChange={(value) => updateField("name", value)}
        />

        <InputField
          label="Email address"
          type="email"
          placeholder="you@example.com"
          icon={<Mail size={18} />}
          value={formData.email}
          onChange={(value) => updateField("email", value)}
        />

        <InputField
          label="Password"
          type={showPassword ? "text" : "password"}
          placeholder="Create a password"
          icon={<Lock size={18} />}
          value={formData.password}
          onChange={(value) => updateField("password", value)}
          endIcon={
            <PasswordToggle
              visible={showPassword}
              onClick={() => setShowPassword(!showPassword)}
            />
          }
        />

        <InputField
          label="Confirm password"
          type={showConfirm ? "text" : "password"}
          placeholder="Confirm your password"
          icon={<Lock size={18} />}
          value={formData.confirmPassword}
          onChange={(value) => updateField("confirmPassword", value)}
          endIcon={
            <PasswordToggle
              visible={showConfirm}
              onClick={() => setShowConfirm(!showConfirm)}
            />
          }
        />

        <label className="terms-label">
          <input type="checkbox" required />
          <span>
            I agree to the terms and privacy policy.
          </span>
        </label>

        <ErrorMessage error={error} />

        <SubmitButton text="Create account" />
      </form>

      <SwitchAuth
        text="Already have an account?"
        action="Sign in"
        onClick={switchMode}
      />
    </motion.div>
  );
}

/* REUSABLE COMPONENTS */

function AuthHeader({ title, subtitle }) {
  return (
    <header className="auth-header">
      <div className="mobile-brand">NEXUS</div>

      <h1>{title}</h1>
      <p>{subtitle}</p>
    </header>
  );
}

function InputField({
  label,
  type,
  placeholder,
  icon,
  value,
  onChange,
  endIcon,
}) {
  return (
    <div className="input-group">
      <label>{label}</label>

      <div className="input-wrapper">
        <span className="input-icon">
          {icon}
        </span>

        <input
          type={type}
          placeholder={placeholder}
          required
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />

        {endIcon && (
          <span className="input-end">
            {endIcon}
          </span>
        )}
      </div>
    </div>
  );
}

function PasswordToggle({ visible, onClick }) {
  return (
    <button
      type="button"
      className="icon-button"
      aria-label={visible ? "Hide password" : "Show password"}
      onClick={onClick}
    >
      {visible ? <EyeOff size={18} /> : <Eye size={18} />}
    </button>
  );
}

function SubmitButton({ text }) {
  return (
    <button type="submit" className="primary-button">
      {text}
      <ArrowRight size={18} />
    </button>
  );
}

function SwitchAuth({ text, action, onClick }) {
  return (
    <div className="switch-auth">
      <span>{text}</span>

      <button
        type="button"
        className="text-link"
        onClick={onClick}
      >
        {action}
      </button>
    </div>
  );
}

function Feature({ text }) {
  return (
    <div className="feature-item">
      <CheckCircle2 size={17} />
      <span>{text}</span>
    </div>
  );
}

function ErrorMessage({ error }) {
  if (!error) return null;

  return (
    <p className="error-message" role="alert">
      {error}
    </p>
  );
}